PlayerInventory._orig = PlayerInventory._orig or {}

--[[PlayerInventory._orig.set_ammo = PlayerInventory._orig.set_ammo or PlayerInventory.set_ammo

function PlayerInventory:set_ammo(ammo)

end]]--
